package com.blakecode.postcodesau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostcodesauApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostcodesauApplication.class, args);
	}

}
